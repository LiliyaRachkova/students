import React from 'react';
import { StyleSheet, Text, View , ScrollView, Image} from 'react-native';
const LotsOfStyles = () => {
    return (
      <View style = {styles.container_1}>
        <Text style={styles.header_syle}>Что есть в холода:</Text>
        <Text style={styles.h2_syle}>лучшие блюда карельской, финской и норвежской кухни</Text>
        <ScrollView style={styles.container}>
        <Text></Text>
        <Text style={styles.bigBlue}>Рыба очень популярна у норвежцев.</Text>
        <Text style={styles.simple_text}>И в холода тоже. Из нее готовят различные горячие блюда, иногда варят суп. Главное правило: рыба должна быть свежей. Именно поэтому ее стараются употреблять только в те месяцы, в названиях которых есть буква «р»: с сентября по май. В теплое время года рыба портится быстрее, плюс она гораздо вкуснее, когда море холодное.</Text>
        <Text></Text>
        <Image
        style={styles.image_style}
        source={{uri:"https://cdn25.img.ria.ru/images/07e5/09/0d/1749841937_0:0:768:1024_900x0_80_0_0_86a84debe1886f8ce222e2d7f579481c.jpg.webp"}}
      />


      <Text></Text>
        <Text style={styles.bigBlue}>На первом месте, конечно, лососевый суп лохикейтто, который обожают все финны.</Text>
        <Text style={styles.simple_text}>Его даже называют «маленьким черным платьем финской кухни».</Text>
        <Text></Text>
        <Image
        style={styles.image_style}
        source={{uri:"https://cdn25.img.ria.ru/images/154950/94/1549509484_0:0:2048:1153_900x0_80_0_0_1906b17ef180815ec97c14c648f40d54.jpg.webp"}}
      />



      <Text></Text>
        <Text style={styles.bigBlue}>В мороз карелы едят обжигающе горячую и очень жирную уху.</Text>
        <Text style={styles.simple_text}>Рыбы нужно положить много, неважно какой — речной, морской или озерной. Карелия — край, где 63 тысячи озер, 25 тысяч рек и одно море. Поэтому рыбы хватает.</Text>
        <Text></Text>
        <Image
        style={styles.image_style}
        source={{uri:"https://cdn25.img.ria.ru/images/07e5/09/0d/1749847357_0:0:2560:1920_900x0_80_0_0_51e273659b7be76d4c9523ae9c08629c.jpg.webp"}}
      />



      </ScrollView>
      </View>
    );
};
const styles = StyleSheet.create({
  container_1: {
    margin:20,
    flex: 1,
    backgroundColor: "white"
  },
  container: {
    margin:10,
    flex: 1,
    backgroundColor: "whitesmoke",
    borderWidth: 1,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    borderBottomLeftRadius:20
  },
  bigBlue: {
    margin:10,
    color: 'firebrick',
    fontWeight: 'bold',
    fontSize: 20,
  },
  h2_syle: {
  
    fontSize: 25,
    textAlign: "center"
  },
  header_syle: {
  margin:10,
    fontSize: 40,
    textAlign: "center"
  },
  simple_text: {
    fontSize: 14
  },
  image_style:{
    margin:10,
    height: 300,
  width:300,
  alignSelf:"center"
  },
});
export default LotsOfStyles;

