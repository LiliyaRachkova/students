 
import React, {useState} from 'react';  
import {StyleSheet, Text,Image, Button, View} from 'react-native'; 


 
 
 const Start = props => {

  function nav(){
      props.navigation.navigate({routeName: 'SecondScreen'});
  }

   
 return (  
        <View style={styles.container}>  
       
       <Text>Start Page </Text>
       <Image
       style={styles.start_image_style}
        source={require('../assets/cat_2.gif')}/>
        <Button title="Second Screen" onPress={nav}/>
        </View>  
    );  
  
 
}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
        backgroundColor: 'white',
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },
    start_image_style: {  
        flex: 1,  
        height:100,
        width:500,
    }

});  

export default  Start;


