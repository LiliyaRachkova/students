 
import React, {useState} from 'react';  
import {StyleSheet, Text, TextInput, Button, View,Image,Dimensions,ImageBackground} from 'react-native'; 


 
 
 const Second = props => {
function nav(){
      props.navigation.navigate({routeName: 'Third Screen'});
  }

   
 return (  
        <View style={styles.container}>  
       <View style={styles.text_container}>
       <Text style = {styles.h1_text}>Добро пожаловать!</Text>
      </View>
      <View style={styles.button_container}>
         <Button title="Third Screen" onPress={nav}/>
           <Button title="Go Back" onPress={() => {
        props.navigation.goBack();
      }}/>
      </View>

        </View>  
    );  
  
 
}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
        backgroundColor: 'white',
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },  
    text_container: {  
        flex: 5,
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },
    h1_text: {  
        fontSize: 40,
        justifyContent: 'center'  
    },
    button_container: {  
        flex: 1,  
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },
});  

export default Second;


