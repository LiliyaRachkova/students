 
import React, {useState} from 'react';  
import {StyleSheet, Text,Item, TextInput, Input,Label, Button, View,Image,Dimensions} from 'react-native'; 


 
 
 const Third = props => {

   
 return (  
        <View style={styles.container}>  
       <View>
       <Text style = {styles.h1_text}>Log In</Text>
       </View>
       <View >
        <TextInput
          style={styles.text_input}
          placeholder="Emaill"
          />
      </View>
 
      <View >
        <TextInput
          style={styles.text_input}
          secureTextEntry={true}
          placeholder="Password"
        />
      </View>
         <Button title="Go Back"
         //onPress={() => {props.navigation.popToTop();}}
         />
        </View>  
    );  
  
 
}


const styles = StyleSheet.create({  
    container: {  
      backgroundColor:'white',
        flex: 1,  
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },
 h1_text: {  
        fontSize: 20,
        justifyContent: 'center'  
    },
  text_input: {
    height: 50,
    flex: 1,
    padding: 10,
    backgroundColor: "#87CEFA",
    borderRadius: 30,
    width: "100%",
    marginBottom: 20,
 
    alignItems: "center"
  } 


});  

export default Third;


