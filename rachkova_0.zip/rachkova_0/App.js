import React from 'react';
import { Text, View } from 'react-native';

const PrintHelloWorld = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text style={{ fontSize: 40 }}>
        Hello, world
      </Text>
    </View>
  );
}

export default PrintHelloWorld ;
